package com.yesbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YesbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
