package com.yesbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.yesbank.entity.Userinfo;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class Emailfunc {
	@Autowired
	private JavaMailSender emailSender;

	public String generateOTP(@ModelAttribute Userinfo ui) {
		// Generate a random 6-digit OTP
		// String otp = generateRandomOTP();
		String id = String.valueOf(ui.getId());
		String email = ui.getEmail();
		// Send OTP to the provided email
		try {
			sendOTPEmail(email, id);
			return "OTP sent successfully!";
		} catch (MessagingException e) {
			return "Failed to send OTP: " + e.getMessage();
		}
	}

//	private String generateRandomOTP() {
//		// Generate a random 6-digit OTP
//		Random random = new Random();
//		int otp = 100_000 + random.nextInt(900_000);
//		return String.valueOf(otp);
//	}

	private void sendOTPEmail(String email, String otp) throws MessagingException {
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);

		helper.setTo(email);
		helper.setSubject("Verification ID");
		helper.setText("Your ID for Login is: " + otp);

		emailSender.send(message);
	}

}