package com.yesbank.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.yesbank.Repository.Transactio;
import com.yesbank.entity.Transaction;

public class Otherfunctions {

	@Autowired
	private static Transaction trans;

	@Autowired
	private static Transactio tr;

	public static void transactionfunction() {
		trans.setBalance(500);
		trans.setTransactions("Account Opening Balance");
		tr.save(trans);
	}

}
