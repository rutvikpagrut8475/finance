package com.yesbank.service;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

public class EmailService {

	private final JavaMailSender emailSender;

	@Autowired
	public EmailService(JavaMailSender emailSender) {
		this.emailSender = emailSender;
	}

	public String generateOTP() {
		// Generate a random 6-digit OTP
		Random random = new Random();
		int otp = 100_000 + random.nextInt(900_000);
		return String.valueOf(otp);
	}

	public void sendOTPEmail(String toEmail, String otp) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(toEmail);
		message.setSubject("OTP for Verification");
		message.setText("Your OTP for verification is: " + otp);

		emailSender.send(message);
	}

}
