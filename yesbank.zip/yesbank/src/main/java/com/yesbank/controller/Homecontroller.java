package com.yesbank.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yesbank.Repository.Transactio;
import com.yesbank.Repository.UserinfoRepository;
import com.yesbank.entity.Transaction;
import com.yesbank.entity.Userinfo;
import com.yesbank.service.Emailfunc;

@Controller
public class Homecontroller {

	@Autowired
	private Emailfunc em;

	@Autowired
	private UserinfoRepository repo;

	@Autowired
	private Transactio transactionRepository;

	@GetMapping("/")
	public String login() {
		return "login";
	}

	@GetMapping("/new")
	public String neow() {
		return "new";
	}

	@PostMapping("/register")
	public String register(@ModelAttribute Userinfo userdata, Model model) {
		repo.save(userdata);

		Transaction transaction = new Transaction();
		transaction.setUser(userdata);
		transaction.setBalance(500);
		transaction.setTransactions("Initial deposit");
		transactionRepository.save(transaction);

		em.generateOTP(userdata);

		return "login";
	}

	@PostMapping("/signin")
	public String enter(@ModelAttribute Userinfo data, Model model) {

		Optional<Userinfo> existingUser = repo.findByUsernameAndPassword(data.getUsername(), data.getPassword());
		if (existingUser.isPresent()) {
			return "dashbord";
		} else {
			model.addAttribute("error", "Invalid username or password");
			return "login";
		}
	}

	@GetMapping("/update-profile")
	public String updateProfile(@RequestParam("id") int userId, Model model) {
		try {
			Userinfo user = repo.findById(userId)
					.orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + userId));
			model.addAttribute("user", user);
			return "updateProfile";
		} catch (IllegalArgumentException e) {
			return "error"; // Handle the error appropriately, e.g., redirect to an error page
		}
	}

	@PostMapping("/save-profile")
	public String saveProfile(@ModelAttribute Userinfo userinfo) {
		repo.save(userinfo);
		return "redirect:/user/view-profile?id=" + userinfo.getId();
	}

	@GetMapping("/transactions")
	public String listTransactions(@RequestParam("userId") int userId, Model model) {
		try {
			List<Transaction> transactions = transactionRepository.findByUserId(userId);
			model.addAttribute("transactions", transactions);
			return "transactions"; // Ensure this view exists
		} catch (Exception e) {
			return "error"; // Handle the error appropriately, e.g., redirect to an error page
		}
	}

	@PostMapping("/transactions")
	public String listTransactionsPost(@RequestParam("userId") int userId, Model model) {
		try {
			List<Transaction> transactions = transactionRepository.findByUserId(userId);
			model.addAttribute("transactions", transactions);
			return "transactions"; // Ensure this view exists
		} catch (Exception e) {
			return "error"; // Handle the error appropriately, e.g., redirect to an error page
		}
	}

}
