package com.yesbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yesbank.Repository.Transactio;
import com.yesbank.entity.Transaction;

@Service
public class Viewcontroller {

	@Autowired
	private Transactio transactionRepository;

	public List<Transaction> getTransactionsByUserId(int userId) {
		return transactionRepository.findByUserId(userId);
	}

}
