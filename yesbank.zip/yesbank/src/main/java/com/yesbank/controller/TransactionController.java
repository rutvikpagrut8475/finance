package com.yesbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yesbank.Repository.Transactio;
import com.yesbank.Repository.UserinfoRepository;
import com.yesbank.entity.Transaction;
import com.yesbank.entity.Userinfo;

@Controller
public class TransactionController {

	@Autowired
	private Transactio transactionRepository;

	@Autowired
	public Transactio trans;

	@Autowired
	public Viewcontroller vc;

	@Autowired
	private UserinfoRepository userinfoRepository;

	@PostMapping("/credit")
	public String credit(@ModelAttribute Transaction transaction, Model model, @RequestParam("amount") int amount,
			@RequestParam("id") int userId) {
		try {
			Userinfo user = userinfoRepository.findById(userId)
					.orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + userId));

			int currentBalance = user.getTransactions().isEmpty() ? 0
					: user.getTransactions().get(user.getTransactions().size() - 1).getBalance();
			int newBalance = currentBalance + amount;

			transaction.setUser(user);
			transaction.setBalance(newBalance);
			transaction.setTransactions("Account credited with " + amount + ". Total amount is " + newBalance);

			trans.save(transaction);
			return "TransactionCompleted";
		} catch (Exception e) {
			// Handle exceptions here, e.g., log the exception or show an error message
			model.addAttribute("errorMessage", "An error occurred during the credit transaction.");
			return "error"; // Create an error view to display the error message
		}
	}

	@PostMapping("/debit")
	public String debit(@ModelAttribute Transaction transaction, Model model, @RequestParam("amount") int amount,
			@RequestParam("id") int userId) {
		try {
			Userinfo user = userinfoRepository.findById(userId)
					.orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + userId));

			int currentBalance = user.getTransactions().isEmpty() ? 0
					: user.getTransactions().get(user.getTransactions().size() - 1).getBalance();
			int newBalance = currentBalance - amount;

			if (newBalance >= 0) {
				transaction.setUser(user);
				transaction.setBalance(newBalance);
				transaction.setTransactions("Account debited with " + amount + ". Total amount is " + newBalance);

				trans.save(transaction);
				return "TransactionCompleted"; // Assuming "TransactionCompleted" is your success view name

			} else {
				return "insufficient"; // Assuming "insufficient" is your insufficient balance view name
			}
		} catch (Exception e) {
			// Log the exception or handle it as needed
			model.addAttribute("errorMessage", "An error occurred during the debit transaction.");
			return "error"; // Assuming "error" is your error view name to display the error message
		}
	}

	@PostMapping("/saveProfile")
	public String update(@ModelAttribute Userinfo up, @RequestParam("id") int id, Model model) {
		try {
			// Find the existing user from the repository
			Userinfo user = userinfoRepository.findById(id)
					.orElseThrow(() -> new IllegalArgumentException("Invalid user ID: " + id));

			// Update user information with the data from the form (up)
			user.setName(up.getName());
			user.setUsername(up.getUsername());
			user.setEmail(up.getEmail());

			// Save the updated user back to the repository
			userinfoRepository.save(user);

			// Add updated user to the model (if needed)
			model.addAttribute("user", user);

			// Redirect to a confirmation page or return a view name
			return "dashboard"; // Replace with your actual profile page URL
		} catch (Exception e) {
			// Handle exceptions here, e.g., log the exception or show an error message
			model.addAttribute("errorMessage", "An error occurred while saving the profile.");
			return "error"; // Create an error view to display the error message
		}
	}

	@GetMapping("/transaction")
	public String listTransactions(@RequestParam("userId") int userId, Model model) {
		try {
			List<Transaction> transactions = vc.getTransactionsByUserId(userId);
			model.addAttribute("transactions", transactions);
			return "jo"; // Ensure this view exists
		} catch (Exception e) {
			// Handle exceptions here, e.g., log the exception or show an error message
			model.addAttribute("errorMessage", "An error occurred while retrieving transactions.");
			return "error"; // Create an error view to display the error message
		}
	}

}
