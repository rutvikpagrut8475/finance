//package com.yesbank.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//
//import com.yesbank.Repository.UserinfoRepository;
//import com.yesbank.entity.Userinfo;
//
//@Controller
//@RequestMapping("/user")
//public class UserinfoController {
//
//	@Autowired
//	private UserinfoRepository userinfoRepository;
//
//	@GetMapping("/view")
//	public String viewProfile(@RequestParam("id") int id, Model model) {
//		Userinfo user = userinfoRepository.findById(id).orElse(null);
//		model.addAttribute("user", user);
//		return "viewProfile";
//	}
//
//	@PutMapping("/update")
//	public String updateProfile(@ModelAttribute Userinfo userinfo) {
//		userinfoRepository.save(userinfo);
//		return "redirect:/user/view?id=" + userinfo.getId();
//	}
//}

package com.yesbank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yesbank.Repository.UserinfoRepository;
import com.yesbank.entity.Userinfo;

@Controller
@RequestMapping("/user")
public class UserinfoController {

	@Autowired
	private UserinfoRepository userinfoRepository;

	@GetMapping("/view")
	public String viewProfile(@RequestParam("id") int id, Model model) {
		Userinfo user = userinfoRepository.findById(id).orElse(null);
		model.addAttribute("user", user);
		return "view-profile"; // Ensure this view exists
	}

	@PostMapping("/view")
	public String viewProfile1(@RequestParam("id") int id, Model model) {
		Userinfo user = userinfoRepository.findById(id).orElse(null);
		model.addAttribute("user", user);
		return "view-profile"; // Ensure this view exists
	}

	@GetMapping("/update")
	public String updateProfileForm(@RequestParam("id") int id, Model model) {
		Userinfo user = userinfoRepository.findById(id).orElse(null);
		model.addAttribute("user", user);
		userinfoRepository.save(user);
		return "updateprofile"; // Ensure this view exists
	}

	@PostMapping("/update")
	public String updateProfile(@ModelAttribute Userinfo userinfo) {
		userinfoRepository.save(userinfo);
		return "redirect:/user/view?id=" + userinfo.getId();
	}
}
