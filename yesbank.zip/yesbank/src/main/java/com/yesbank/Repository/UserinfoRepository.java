package com.yesbank.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yesbank.entity.Userinfo;

public interface UserinfoRepository extends JpaRepository<Userinfo, Integer> {

	Optional<Userinfo> findByUsernameAndPassword(String username, String password);
}