
package com.yesbank.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yesbank.entity.Transaction;

public interface Transactio extends JpaRepository<Transaction, Long> {
	List<Transaction> findByUserId(int userId);
}
