package com.yesbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YesbankApplication {

	public static void main(String[] args) {
		SpringApplication.run(YesbankApplication.class, args);
	}

}
